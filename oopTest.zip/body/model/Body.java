package com.oop.body.model;

public class Body {

	public Body() {
		
	}
	
	public void action(Body body) {
		
	}
	
}
